public interface G {

    int hh();

    Object pp();
}
