public class A extends null {

    int ae();

    long ac();

    public int cc() {
        return 42;
    }

    public Object gg() {
        return new java.util.Random();
    }

    public void aa() {
        return;
    }
}
