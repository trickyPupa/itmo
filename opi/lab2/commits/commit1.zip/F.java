public class F extends K {

    private String f = "hello";

    private byte c = 1;

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public double ad() {
        return 9.11;
    }

    public void aa() {
        return;
    }
}
