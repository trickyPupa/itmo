public class A extends null {

    int ae();

    long ac();

    public int cc() {
        return 42;
    }
}
