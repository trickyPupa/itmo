public class G extends null {

    int hh();

    Object pp();

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }
}
