public interface A {

    int ae();

    long ac();
}
