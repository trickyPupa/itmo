public class K implements G, A {

    private double f = 100.500;

    private double a = 100.500;

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public Object pp() {
        return this;
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public long ac() {
        return 111;
    }

    public double ad() {
        return 11;
    }

    public double ee() {
        return java.lang.Math.PI;
    }

    public float ff() {
        return 3.14;
    }
}
