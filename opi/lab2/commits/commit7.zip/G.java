public class G extends null {

    int hh();

    Object pp();
}
