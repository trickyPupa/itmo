public class F extends K {

    private String f = "hello";

    private byte c = 1;

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public double ad() {
        return 9.11;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public void aa() {
        return;
    }

    public String kk() {
        return "Hello world";
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public void ab() {
        System.out.println();
    }

    public long dd() {
        return 100500;
    }

    public Object rr() {
        return null;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }
}
