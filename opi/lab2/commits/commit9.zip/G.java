public class G extends null {

    int hh();

    Object pp();

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }
}
